#ifndef MINT_THREADS_H

struct mint_network;

void mint_network_init_threads( struct mint_network *net, float *p );

#endif /* MINT_THREAD_H */

