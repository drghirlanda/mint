#include "random.h"

#include <stdio.h>

int main(void) {
  int i;
  for( i=0; i<10000; i++ )
    printf( "%f %f\n", mint_random(), mint_random() );
  return 0;
}
